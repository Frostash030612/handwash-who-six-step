"""Publication figures: identical geometry in editable SVG and vector PDF."""
from pathlib import Path
from xml.sax.saxutils import escape
import math
import base64
from reportlab.pdfgen import canvas
from reportlab.pdfbase.pdfmetrics import stringWidth, registerFont
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.lib.utils import ImageReader
from reportlab.lib.colors import toColor as HexColor
import pypdfium2 as pdfium

OUT = Path(__file__).parent / 'figures'
registerFont(TTFont('ComicSans', '/System/Library/Fonts/Supplemental/Comic Sans MS.ttf'))
registerFont(TTFont('ComicSans-Bold', '/System/Library/Fonts/Supplemental/Comic Sans MS Bold.ttf'))
INK='#354052'; MUTED='#68778A'; GRID='#E8EAF0'
BLUE='#537EA7'; PURPLE='#8872A6'; TEAL='#408C80'; ORANGE='#BD9059'; RED='#BC687C'

class Figure:
    def __init__(self,name,w,h):
        self.name,self.w,self.h=name,w,h
        self.c=canvas.Canvas(str(OUT/f'{name}.pdf'),pagesize=(w,h))
        self.c.setTitle({'architecture':'YOLO with adaptive boundary-aware GRU','comparison':'Four-model performance: grouped bars and action-chain lines'}[name])
        self.svg=[f'<svg xmlns="http://www.w3.org/2000/svg" width="{w}" height="{h}" viewBox="0 0 {w} {h}">', '<rect width="100%" height="100%" fill="white"/>']
    def text(self,x,y,s,size=16,color=INK,bold=False,anchor='start'):
        self.svg.append(f'<text x="{x}" y="{y}" fill="{color}" font-family="Comic Sans MS,cursive" font-size="{size}" font-weight="{700 if bold else 400}" text-anchor="{anchor}">{escape(s)}</text>')
        c=self.c;c.setFillColor(HexColor(color));c.setFont('ComicSans-Bold' if bold else 'ComicSans',size)
        {'start':c.drawString,'middle':c.drawCentredString,'end':c.drawRightString}[anchor](x,self.h-y,s)
    def rect(self,x,y,w,h,fill='white',stroke=None,r=0,lw=1):
        self.svg.append(f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="{r}" fill="{fill}" stroke="{stroke or "none"}" stroke-width="{lw}"/>')
        c=self.c;c.setFillColor(HexColor(fill));c.setStrokeColor(HexColor(stroke or fill));c.setLineWidth(lw)
        c.roundRect(x,self.h-y-h,w,h,r,fill=1,stroke=int(bool(stroke)))
    def path(self,pts,color=MUTED,lw=1.6,dash=False,arrow=False):
        c=self.c;c.setStrokeColor(HexColor(color));c.setLineWidth(lw);c.setDash([6,5] if dash else [])
        c.setLineCap(1);c.setLineJoin(1)
        p=c.beginPath();p.moveTo(pts[0][0],self.h-pts[0][1])
        d=[f'M {pts[0][0]} {pts[0][1]}']
        for i,(x,y) in enumerate(pts[1:],1):
            if self.name=='architecture' and i<len(pts)-1:
                a,b=pts[i-1],pts[i+1]
                l1=math.dist(a,(x,y));l2=math.dist(b,(x,y));r=min(8,l1/3,l2/3)
                u=(x+(a[0]-x)*r/l1,y+(a[1]-y)*r/l1)
                v=(x+(b[0]-x)*r/l2,y+(b[1]-y)*r/l2)
                d.append(f'L {u[0]} {u[1]} Q {x} {y} {v[0]} {v[1]}')
                p.lineTo(u[0],self.h-u[1])
                p.curveTo(u[0]+2*(x-u[0])/3,self.h-(u[1]+2*(y-u[1])/3),v[0]+2*(x-v[0])/3,self.h-(v[1]+2*(y-v[1])/3),v[0],self.h-v[1])
            else:
                d.append(f'L {x} {y}');p.lineTo(x,self.h-y)
        self.svg.append(f'<path d="{" ".join(d)}" fill="none" stroke="{color}" stroke-width="{lw}" stroke-linecap="round" stroke-linejoin="round"'+(' stroke-dasharray="6 5"' if dash else '')+'/>')
        c.drawPath(p);c.setDash([])
        if arrow:
            x,y=pts[-1];xx,yy=pts[-2];a=math.atan2(y-yy,x-xx);l=7
            pp=[(x,y),(x-l*math.cos(a-.5),y-l*math.sin(a-.5)),(x-l*math.cos(a+.5),y-l*math.sin(a+.5))]
            self.svg.append(f'<polygon points="{" ".join(f"{u},{v}" for u,v in pp)}" fill="{color}"/>')
            p=c.beginPath();p.moveTo(x,self.h-y)
            for u,v in pp[1:]:p.lineTo(u,self.h-v)
            p.close();c.setFillColor(HexColor(color));c.drawPath(p,fill=1,stroke=0)
    def circle(self,x,y,r,color,fill='white',lw=2):
        self.svg.append(f'<circle cx="{x}" cy="{y}" r="{r}" fill="{fill}" stroke="{color}" stroke-width="{lw}"/>')
        c=self.c;c.setStrokeColor(HexColor(color));c.setFillColor(HexColor(fill));c.setLineWidth(lw);c.circle(x,self.h-y,r,fill=1,stroke=1)
    def box(self,x,y,w,h,title,lines,color,fill='white'):
        self.rect(x,y,w,h,fill,color,13,0.95)
        self.text(x+12,y+25,title,min(17,17*(w-24)/stringWidth(title,'ComicSans-Bold',17)),color,True)
        for i,s in enumerate(lines):self.text(x+12,y+47+19*i,s,min(14.5,14.5*(w-24)/stringWidth(s,'ComicSans',14.5)),MUTED)
    def group(self,x,y,w,h,n,title,color,tint):
        self.rect(x,y,w,h,tint,None,18)
        self.circle(x+26,y+23,13,color,'white',1)
        self.text(x+26,y+28,n,12,color,True,'middle');self.text(x+47,y+28,title,min(17,17*(w-59)/stringWidth(title,'ComicSans-Bold',17)),color,True)
    def save(self):
        self.svg.append('</svg>');(OUT/f'{self.name}.svg').write_text('\n'.join(self.svg))
        self.c.showPage();self.c.save()
        doc=pdfium.PdfDocument(str(OUT/f'{self.name}.pdf'))
        doc[0].render(scale=1.7).to_pil().save(OUT/f'{self.name}_preview.png');doc.close()

f=Figure('architecture',1200,596)
f.text(20,32,'YOLO + Adaptive Boundary-Aware GRU',25,INK,True)
f.group(20,72,280,286,'01','Visual encoder',BLUE,'#F0F5FB')
f.group(320,72,250,286,'02','Temporal encoder',PURPLE,'#F5F1FA')
f.group(590,72,260,286,'03','Two prediction heads',TEAL,'#EFF7F6')
f.group(870,72,310,286,'04','Action segmentation',ORANGE,'#FCF6ED')
# Real frame, scaled as a small image; all other components remain vector.
photo=OUT/'action_example.jpg'
f.rect(38,125,154,101,'white',BLUE,12,.9)
f.c.drawImage(ImageReader(str(photo)),44,f.h-220,142,89,preserveAspectRatio=True,anchor='c',mask='auto')
f.svg.append(f'<image x="44" y="131" width="142" height="89" href="data:image/jpeg;base64,{base64.b64encode(photo.read_bytes()).decode()}" preserveAspectRatio="xMidYMid meet"/>')
f.text(211,161,'RGB',16,BLUE,True)
f.text(204,183,'1088',14,MUTED)
f.text(204,205,'5 fps',14,MUTED)
# Stacked feature maps: graphic representation of the visual backbone.
for j in range(3):
    x,y=62+j*10,260-j*7
    f.rect(x,y,72,56,['#D8E5F0','#AFC8DF','#729BBC'][j],BLUE,6,.9)
    for u in range(3):
        for v in range(2):f.rect(x+12+u*17,y+10+v*18,10,10,'#E8F0F7',r=2)
f.path([(114,226),(114,244)],BLUE,arrow=True)
f.text(113,342,'YOLO26m-cls',15,BLUE,True,'middle')
for u in range(5):
    for v in range(5):f.rect(211+u*9,260+v*9,6,6,['#AFC8DF','#729BBC','#D8E5F0'][(u+v)%3],r=1)
f.path([(157,283),(202,283)],BLUE,arrow=True)
f.text(232,332,'1280-D',14,BLUE,False,'middle')
# Temporal projection and unrolled shared recurrent cells.
f.box(338,126,214,54,'Normalize + project',[],PURPLE)
f.text(445,204,'1280  >  128',14,PURPLE,anchor='middle')
f.path([(260,283),(310,283),(310,153),(338,153)],BLUE,arrow=True)
f.path([(445,211),(445,225)],PURPLE)
f.path([(370,235),(370,225),(520,225),(520,235)],PURPLE,arrow=True)
f.path([(445,225),(445,235)],PURPLE,arrow=True)
f.path([(370,225),(370,235)],PURPLE,arrow=True)
for x in [338,413,488]:
    f.rect(x,238,64,62,'white',PURPLE,14,1.1)
    f.text(x+32,264,'GRU',16,PURPLE,True,'middle')
    f.circle(x+22,283,4,PURPLE,'#DED6EB',1);f.circle(x+43,283,4,PURPLE,'#DED6EB',1)
f.path([(402,269),(413,269)],PURPLE,arrow=True);f.path([(477,269),(488,269)],PURPLE,arrow=True)
f.text(370,324,'t-2',13,MUTED,anchor='middle');f.text(445,324,'t-1',13,MUTED,anchor='middle');f.text(520,324,'t',13,MUTED,anchor='middle')
f.text(445,347,'Shared weights  |  h: 128-D',13,PURPLE,anchor='middle')
# Branch into probability bars and state-change boundary evidence.
f.path([(552,269),(579,269),(579,151),(608,151)],PURPLE,arrow=True)
f.rect(608,122,224,80,'white',TEAL,12,.9)
f.text(619,144,'Class head',16,TEAL,True)
for k,h in enumerate([11,16,9,32,14,7,10]):f.rect(626+27*k,190-h,15,h,TEAL if k==3 else '#BADAD4',r=3)
f.text(810,218,'7 classes',13,TEAL,anchor='end')
f.path([(579,269),(608,269)],PURPLE,arrow=True)
f.rect(608,240,224,92,'white',TEAL,12,.9)
f.text(619,264,'Boundary head',16,TEAL,True)
f.text(619,288,'[ h(t), | h(t)-h(t-1) | ]',13,MUTED)
f.path([(625,317),(650,317),(658,300),(665,317),(706,317),(715,297),(724,317),(810,317)],TEAL,1.7)
# Symbolic probability stream and detected boundary peaks.
f.text(890,132,'Boundary peaks',16,ORANGE,True)
f.path([(832,285),(860,285),(860,171),(888,171)],TEAL,arrow=True)
f.path([(890,187),(922,186),(932,161),(941,186),(988,187),(1000,154),(1009,186),(1055,186),(1067,160),(1076,186),(1158,187)],ORANGE,2)
for x in [932,1000,1067]:
    f.path([(x,145),(x,274)],'#CDBCA4',1,dash=True)
    f.circle(x,145,3,ORANGE,ORANGE,1)
f.path([(832,160),(856,160),(856,225),(890,225)],TEAL,arrow=True)
colors=[BLUE,TEAL,PURPLE,ORANGE,RED]
for x,w,col in [(890,41,BLUE),(935,62,TEAL),(1003,61,PURPLE),(1070,88,ORANGE)]:
    f.rect(x,229,w,40,col,r=5)
f.text(1025,298,'Segment mean probabilities',15,ORANGE,True,'middle')
f.text(1025,327,'peak > 0.3  |  gap: 4',13,MUTED,anchor='middle')
# Training branch: compact loss nodes instead of explanatory paragraphs.
f.group(20,393,550,158,'T','Training objectives',PURPLE,'#F7F4FA')
for x,label in [(67,'CE'),(201,'BCE'),(335,'Interval')]:
    f.rect(x,447,104,40,'white',PURPLE,16,.9);f.text(x+52,473,label,16,PURPLE,True,'middle')
f.text(188,474,'+',18,PURPLE,anchor='middle');f.text(322,474,'+',18,PURPLE,anchor='middle')
for x,label,size,y in [(136,'L',17,526),(155,'=',17,526),(180,'L',17,526),(192,'cls',11,531),(220,'+',17,526),(244,'0.35 L',17,526),(301,'bnd',11,531),(341,'+',17,526),(365,'0.5 L',17,526),(413,'int',11,531)]:f.text(x,y,label,size,PURPLE,True)
f.path([(720,332),(720,375),(550,375),(550,437)],PURPLE,dash=True,arrow=True)
# Adaptive confirmation: short uncertain run fades; confirmed chain stays visible.
f.group(590,393,590,158,'05','Adaptive confirmation',TEAL,'#EFF7F6')
f.text(608,452,'Duration + confidence',15,TEAL,True)
for x,w,col in [(608,45,BLUE),(657,11,'#E9CAD1'),(672,54,TEAL),(730,44,PURPLE)]:f.rect(x,467,w,32,col,r=6)
f.path([(662,506),(662,515)],RED,1)
f.text(662,532,'uncertain',12,MUTED,anchor='middle')
f.path([(785,482),(811,482)],TEAL,arrow=True)
f.rect(819,459,131,47,'white',TEAL,15,.9);f.text(884,489,'Median / MAD',15,TEAL,True,'middle')
f.path([(959,482),(985,482)],TEAL,arrow=True)
for k,col in enumerate([BLUE,TEAL,PURPLE]):
    f.circle(1006+k*59,482,18,col,col,1)
    f.text(1006+k*59,488,str(k+1),16,'white',True,'middle')
f.path([(1024,482),(1045,482)],TEAL,arrow=True);f.path([(1083,482),(1104,482)],TEAL,arrow=True)
f.text(1065,532,'Confirmed chain',14,TEAL,True,'middle')
f.path([(1025,343),(1025,367),(581,367),(581,483),(608,483)],ORANGE,arrow=True)
f.path([(24,576),(58,576)],MUTED,arrow=True);f.text(68,581,'Inference',13,MUTED)
f.path([(183,576),(217,576)],PURPLE,dash=True,arrow=True);f.text(227,581,'Training',13,MUTED)
f.text(1180,581,'Signals and segments are schematic.',12,MUTED,anchor='end')
f.save()

f=Figure('comparison',1200,615)
f.text(28,34,'Recognition quality and complete action chains',25,INK,True)
f.text(28,61,'10 reviewed videos  /  632 aligned valid centers  /  common 0-100% scale',16,MUTED)
# Shared legend: bars on first row, line series on second row.
for x,lab,col in [(28,'Frame accuracy',BLUE),(235,'Macro F1',TEAL),(402,'Boundary F1',PURPLE)]:
    f.rect(x,88,17,17,col,r=2);f.text(x+26,102,lab,16)
f.path([(650,97),(694,97)],RED,3);f.circle(672,97,5,RED);f.text(706,102,'Final chain match',16)
f.path([(923,97),(967,97)],INK,2,dash=True);f.rect(940,92,10,10,'white',INK,lw=1.6);f.text(979,102,'Raw chain match',16)
left,right,top,bottom=87,1155,185,543
Y=lambda v:bottom-v*(bottom-top)/100
centers=[218,487,756,1025]
# Highlight one group without hiding competing results.
f.rect(651,151,210,428,'#F0F7F5',r=8)
for v in range(0,101,20):
    y=Y(v);f.path([(left,y),(right,y)],GRID,1);f.text(left-15,y+5,str(v),14,MUTED,anchor='end')
f.text(30,164,'Score (%)',14,MUTED)
f.path([(left,bottom),(right,bottom)],'#A6B1C0',1)
metrics=[([95.25,96.04,96.52,99.53],BLUE),([93.84,93.58,93.71,99.02],TEAL),([76.92,87.59,94.40,97.48],PURPLE)]
for i,cx in enumerate(centers):
    for k,(values,color) in enumerate(metrics):
        v=values[i];x=cx-66+k*46
        f.rect(x,Y(v),40,bottom-Y(v),color,r=5)
        f.text(x+20,Y(v)+(48 if k==0 and i>=2 else 23),f'{v:.2f}',12.5,'#FFFFFF',True,'middle')
raw=[20,60,80,100];final=[20,60,100,100]
# White under-strokes retain line legibility where lines cross the bars.
f.path([(x,Y(v)) for x,v in zip(centers,final)],'white',6)
f.path([(x,Y(v)) for x,v in zip(centers,final)],RED,3.1)
f.path([(x,Y(v)) for x,v in zip(centers,raw)],'white',4.7)
f.path([(x,Y(v)) for x,v in zip(centers,raw)],INK,1.8,dash=True)
for x,r,v in zip(centers,raw,final):
    f.rect(x-6,Y(r)-6,12,12,'white',INK,lw=1.8)
    f.circle(x,Y(v),4.5,RED,'white',2.2)
# Labels sit on white plaques for a clean overlay on filled columns.
def tag(x,y,w,s,col):
    f.rect(x-w/2,y-17,w,25,'white',r=3)
    f.text(x,y,s,14,col,True,'middle')
tag(218,Y(20)-16,105,'2/10 - both',INK)
tag(487,Y(60)-16,105,'6/10 - both',INK)
tag(756,Y(80)+31,102,'Raw: 8/10',INK)
tag(756,167,117,'Final: 10/10',RED)
tag(1025,167,115,'10/10 - both',INK)
f.path([(835,Y(80)),(835,Y(100))],RED,1.5,arrow=True)
f.text(848,Y(94)+5,'+20 pp',12.5,RED,True)
for x,name in zip(centers,['YOLO','YOLO + GRU','Adaptive boundary GRU','VideoMAE']):f.text(x,569,name,16,INK,True,'middle')
f.text(756,591,'Proposed model',13,TEAL,anchor='middle')
f.save()
print('Created vector SVG/PDF figures and rendered PNG previews.')
