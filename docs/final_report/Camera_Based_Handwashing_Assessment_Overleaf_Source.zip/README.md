# Camera-Based Handwashing Assessment

Group 43 · Shen Ziyi · Wang Lepeng · Xu Wenzhe · Zhu Jianyu

## Report

The compiled report contains 45 pages: three pages of front matter, 37 pages of main discussion, one reference page and four appendix pages. It integrates 24 figures, nine tables, 24 numbered equations and an algorithm in a single-column layout.

The report explains the task, preliminary PSKUS study, self-recorded annotation corpus, visual and recurrent representations, boundary supervision, adaptive confirmation, training provenance, evaluation, per-video cases and local deployment. Figure numbers follow their narrative order and differ from the companion figure atlas.

## Open in Overleaf

1. Choose **New Project → Upload Project** and upload the supplied ZIP.
2. Select `main.tex` as the main document.
3. Set the compiler to **XeLaTeX**.
4. Recompile; references and the contents update automatically. A second compilation may be needed after editing.

The project uses ordinary LaTeX packages and embedded vector PDF figures. No custom system font is required to compile it. The figures already embed their fonts. Model weights, Python and the camera backend are not required for document compilation.

## Files

- `main.tex`: document setup, title, front matter and section order.
- `sections/`: editable chapter text, bibliography and appendices.
- `tables/`: native full-width LaTeX tables and their CSV values.
- `figures/`: the 24 PDF figures used by the report.
- `figure_sources/`: corresponding editable SVG files.
- `report_manifest.json`: document inventory and PDF checksum.

The report's source citations identify the public references and retained project records. The full figure atlas separately contains the evidence snapshots and figure-generation scripts.
