# Camera-Based Handwashing Assessment

Upload `handwash_report_overleaf_en.zip` to Overleaf with **New Project → Upload Project**. Select **XeLaTeX**, set `main.tex` as the main document and recompile.

The report uses a single-column A4 layout with compact paragraph and float spacing. The architecture appears as Figure 1 in the opening system overview. The camera screenshot is sized to share a page with the deployment discussion. All data tables span the text width and wrap long entries. Equations use mathematical subscripts, numbered equations and automatic cross-references. Algorithm 1 describes the inference procedure.

## Author information

The title page identifies **Group 43**, with a compact two-line group-and-author block. Members are listed alphabetically by surname: **Shen Ziyi, Wang Lepeng, Xu Wenzhe, Zhu Jianyu**. The `\GroupID` and `\GroupMembers` definitions near the start of `main.tex` control these fields.

## Figures

- `six_actions.pdf`: six self-recorded action examples.
- `architecture.pdf`: illustrated model structure with a real input thumbnail.
- `comparison.pdf`: performance bars with overlaid action-chain lines.
- `system_page.png`: the supplied application screenshot.

The architecture and comparison PDFs embed Comic Sans MS and are ready for Overleaf without installing the font. Their SVG versions are also included; editable SVG text requires Comic Sans MS locally. `make_figures.py` reproduces those two figures using ReportLab, pypdfium2 and the macOS Comic Sans fonts. Figure notes explaining evaluation scope are in the report captions.

The figures, equations, pseudocode and reported metrics are referenced directly in `main.tex`. Data and evaluation provenance appear in the bibliography.

Compile `main.tex` to generate the current PDF. The abstract uses 11-point text with 15-point line spacing and additional vertical separation.

Displayed relations are centered individually. Related feature, state and confidence equations use lettered subnumbers; trailing display punctuation is omitted.

The opening abstract and system overview are expanded, with compact title spacing. Consecutive equations share a single centered gather environment with a 7-point inter-row setting, including transitions between lettered equation groups.
